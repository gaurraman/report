package com.demo.springboot.angular.springangular.service;

public interface Personservice {

}
