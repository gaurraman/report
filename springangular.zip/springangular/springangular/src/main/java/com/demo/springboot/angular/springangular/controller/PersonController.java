package com.demo.springboot.angular.springangular.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.demo.springboot.angular.springangular.response.Response;

@RestController
public class PersonController {

	@GetMapping(value = "/test/{personName}")
	public ResponseEntity<List<Personentity>> getPersons(){
		List<personentity> person = nwe ArrayList<Personentity>
		return ResponseEntity<List<Personentity>>(null,HttpStatus.OK);
	}

}
