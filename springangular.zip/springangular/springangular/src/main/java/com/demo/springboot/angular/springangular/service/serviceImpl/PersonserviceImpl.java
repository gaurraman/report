package com.demo.springboot.angular.springangular.service.serviceImpl;

public class PersonserviceImpl {

}
