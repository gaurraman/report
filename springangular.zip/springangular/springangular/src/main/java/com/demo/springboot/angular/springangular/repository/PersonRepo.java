package com.demo.springboot.angular.springangular.repository;

public interface PersonRepo extends JpaRepository<Personentity Long> {

}
