package com.demo.springboot.angular.springangular;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringangularApplicationTests {

	@Test
	void contextLoads() {
	}

}
